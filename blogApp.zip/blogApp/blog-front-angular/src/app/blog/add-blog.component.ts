import { Component,OnInit } from '@angular/core';
import {Location} from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { AppComponent } from '../app.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


import { Blog } from '../models/blog.model';
import { BlogService } from './blog.service';

@Component({
  selector: 'add-blog',
  templateUrl: './add-blog.component.html'
})
export class AddBlogComponent  implements OnInit{
  
  blog: Blog = new Blog();
  pageTitle;

  constructor(private formBuilder: FormBuilder,private appComponent: AppComponent,private route: ActivatedRoute, private blogService: BlogService, private location: Location) {

  }
  
  
  ngOnInit() {
 
    const id = +this.route.snapshot.paramMap.get('id');
    if (id !== 0) {
        this.blogService.getBlog(id)
             .subscribe(data => {this.blog = data;
         });
         this.pageTitle = "Edit Blog";
    }else{
    	this.pageTitle = "Create new blog";
    }
   
  }


  addBlog(): void {
   
    
    	this.blogService.createBlog(this.blog)
        .subscribe( data => {
           this.appComponent.alsertClosed = false;
           this.appComponent.alsertMessage = 'The blog with title "'+ this.blog.title+'" has been created successfully.';
           this.goBack();
        });

    
  }
  
  

  goBack(): void {
     this.location.back();
  }
  
  onSubmit() {
    this.addBlog();
  }
}
